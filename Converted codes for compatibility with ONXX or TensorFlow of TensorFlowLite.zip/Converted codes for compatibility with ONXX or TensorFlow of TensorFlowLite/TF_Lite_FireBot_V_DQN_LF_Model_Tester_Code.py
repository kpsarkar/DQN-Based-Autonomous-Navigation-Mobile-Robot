Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import time
import numpy as np
import tflite_runtime.interpreter as tflite
import wrapper

# Convert sensor values to binary states for Firebot
def convert_to_binary_states(sensor_values):
...     binary_states = [1 if 30 < value < 140 else 0 for value in sensor_values]
...     return binary_states
... 
... # Constants
... MAX_SPEED = 100
... 
... # Load the TensorFlow Lite model
... model_path = 'Model_TF_Lite.tflite'
... interpreter = tflite.Interpreter(model_path=model_path)
... interpreter.allocate_tensors()
... input_details = interpreter.get_input_details()
... output_details = interpreter.get_output_details()
... 
... # Function to run inference
... def run_inference(state):
...     interpreter.set_tensor(input_details[0]['index'], state)
...     interpreter.invoke()
...     output_data = interpreter.get_tensor(output_details[0]['index'])
...     return output_data
... 
... # Main loop
... def firebot_main_loop():
...     while True:
...         # Read sensor values from Firebot
...         valueL = wrapper.left_white_read("f") 
...         valueC = wrapper.centre_white_read("g")
...         valueR = wrapper.right_white_read("h")
...         gsValues = [valueL, valueC, valueR]
...         state = np.array(convert_to_binary_states(gsValues), dtype=np.float32).reshape(1, -1)  # Convert to binary states and reshape for TFLite
... 
...         q_values = run_inference(state)
...         action = np.argmax(q_values)
... 
...         # Translate the action to Firebot motor commands
...         leftSpeed, rightSpeed = translate_action_to_firebot_commands(action, MAX_SPEED)
...         command = f"m{leftSpeed}#{rightSpeed}!"
...         wrapper.move_bot(command)
... 
        time.sleep(0.1)

# The function to translate actions to motor speeds
def translate_action_to_firebot_commands(action, max_speed):
    leftSpeed = max_speed
    rightSpeed = max_speed
    if action == 1:
        leftSpeed = int(max_speed / 2)
    elif action == 2:
        rightSpeed = int(max_speed / 2)
    return leftSpeed, rightSpeed

# Run the main loop
firebot_main_loop()
