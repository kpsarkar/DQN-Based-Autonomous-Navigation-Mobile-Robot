#Model Testing code for epuck robot in webots
import torch
import torch.nn as nn
import numpy as np
from controller import Supervisor

# DQN Architecture (same as provided)
class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Convert sensor values to binary states (same as provided)
def convert_to_binary_states(sensor_values):
    binary_states = [1 if value > 600 else 0 for value in sensor_values]
    return binary_states

# Constants (same as provided)
TIME_STEP = 2
MAX_SPEED = 6.28

# Create the Supervisor instance (same as provided)
robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

# Initialize devices (ground sensors and motors) (same as provided)
gs = []
gsNames = ['gs0', 'gs1', 'gs2']
for i in range(3):
    gs.append(robot.getDevice(gsNames[i]))
    gs[i].enable(timestep)

leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# Load the trained DQN model
model_path = 'dqn_model_episode_20.pth'  # You can change this to the path of your trained model
policy_net = DQN(3, 3)
policy_net.load_state_dict(torch.load(model_path))
policy_net.eval()  # Set the model to evaluation mode

# Testing loop
while robot.step(timestep) != -1:
    gsValues = [gs[i].getValue() for i in range(3)]
    state = np.array(convert_to_binary_states(gsValues))  # Convert to binary states
    
    with torch.no_grad():
        q_values = policy_net(torch.tensor(state).float().unsqueeze(0))
        action = q_values.argmax().item()

    # Set motor speeds based on the action
    leftSpeed = 0
    rightSpeed = 0
    if action == 0:
        leftSpeed = MAX_SPEED
        rightSpeed = MAX_SPEED
    elif action == 1:
        leftSpeed = MAX_SPEED / 2
        rightSpeed = MAX_SPEED
    elif action == 2:
        leftSpeed = MAX_SPEED
        rightSpeed = MAX_SPEED / 2

    leftMotor.setVelocity(leftSpeed)
    rightMotor.setVelocity(rightSpeed)
