#Model Testing Code for Firebird V robot in real environment
import time
import torch
import torch.nn as nn
import numpy as np

# Assuming the wrapper functions are in a file named 'wrapper.py'
import wrapper

# DQN Architecture
class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Convert sensor values to binary states for Firebot
def convert_to_binary_states(sensor_values):
    binary_states = [1 if 30 < value < 140 else 0 for value in sensor_values]
    return binary_states

# Constants
MAX_SPEED = 100  # Assuming 100 is the max speed for Firebot as per the line follower script

# Load the trained DQN model
... model_path = 'dqn_model_one.pth'
... policy_net = DQN(3, 3)
... policy_net.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
... policy_net.eval()  # Set the model to evaluation mode
... 
... # Main loop
... def firebot_main_loop():
...     while True:
...         # Read sensor values from Firebot
...         valueL = wrapper.left_white_read("f") 
...         valueC = wrapper.centre_white_read("g")
...         valueR = wrapper.right_white_read("h")
...         gsValues = [valueL, valueC, valueR]
...         state = np.array(convert_to_binary_states(gsValues))  # Convert to binary states
... 
...         with torch.no_grad():
...             q_values = policy_net(torch.tensor(state).float().unsqueeze(0))
...             action = q_values.argmax().item()
... 
...         # Translate the action to Firebot motor commands
...         leftSpeed, rightSpeed = translate_action_to_firebot_commands(action, MAX_SPEED)
...         command = f"m{leftSpeed}#{rightSpeed}!"
...         wrapper.move_bot(command)
... 
...         # sleep might be required, depending on how fast  loop runs
...         time.sleep(0.1)  # Adjust as necessary for your timing needs
... 
... # The function to translate actions to motor speeds
... def translate_action_to_firebot_commands(action, max_speed):
...     leftSpeed = max_speed
...     rightSpeed = max_speed
...     if action == 1:
...         leftSpeed = int(max_speed / 2)
...     elif action == 2:
...         rightSpeed = int(max_speed / 2)
...     return leftSpeed, rightSpeed
... 
... # Run the main loop
... firebot_main_loop()
